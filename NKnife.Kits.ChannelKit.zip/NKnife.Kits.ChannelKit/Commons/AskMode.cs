﻿namespace NKnife.Kits.ChannelKit.Commons
{
    public enum AskMode
    {
        Single,
        Multiterm,
        User
    }
}
