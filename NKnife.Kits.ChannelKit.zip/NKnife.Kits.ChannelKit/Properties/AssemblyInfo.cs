﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NKnife Serial Debugger")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NKnife Serial Debugger")]
[assembly: AssemblyCopyright("Copyright © 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: Guid("ce614ca3-a9b3-4da5-8911-9b47497b47eb")]

[assembly: AssemblyVersion("1.0.18.409")]
[assembly: AssemblyFileVersion("1.0.18.409")]
